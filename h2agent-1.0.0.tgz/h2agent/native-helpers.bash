#!/bin/echo "source me!"

#############
# VARIABLES #
#############
PNAME=${PNAME:-h2agent}

TRAFFIC_PORT=${TRAFFIC_PORT:-8000} # maybe proxy on 8001 ...
[ "${TRAFFIC_SERVER_API}" = "/" ] && TRAFFIC_SERVER_API=
ADMIN_PORT=${ADMIN_PORT:-8074} # maybe proxy on 8075 ...
ADMIN_SERVER_API="admin/v1"
METRICS_PORT=${METRICS_PORT:-8080}

SCHEME=${SCHEME:-http}
CURL=${CURL:-"curl -s -i --http2-prior-knowledge"} # may be just --http2, --http1.0, --http1.1, or nothing
SERVER_ADDR=${SERVER_ADDR:-localhost}

BEAUTIFY_JSON=yes

#############
# FUNCTIONS #
#############

# -----------------------------------------------------------------------------
# INTERNAL

traffic_url() {
  echo "${SCHEME}://${SERVER_ADDR}:${TRAFFIC_PORT}"
}

admin_url() {
  echo -n "${SCHEME}://${SERVER_ADDR}:${ADMIN_PORT}/${ADMIN_SERVER_API}"
}

metrics_url() {
  echo "${SCHEME}://${SERVER_ADDR}:${METRICS_PORT}/metrics"
}

do_curl() {
  echo
  echo [${CURL} $@]
  echo
  ${CURL} $@ | tee /tmp/curl.out
  [ $? -ne 0 ] && return 1

  [ -n "${PLAIN}" ] && echo && return 0 # special for trace()

  # Last empty line or no line feed (no body answered):
  [ -z $(tail -c 1 /tmp/curl.out) ] && return 0

  [ -n "${BEAUTIFY_JSON}" ] && echo -e "\n\nPRETTY BODY PRINTOUT (disable on curl operation unsetting 'BEAUTIFY_JSON'):" && pretty
  echo -e "\n\n(type 'pretty' or 'raw' to isolate body printout)\n"
}

# -----------------------------------------------------------------------------
# GENERAL RESOURCES

schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: schema [-h|--help] [--clean] [file]; Cleans/gets/updates current schema configuration ($(admin_url)/schema)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/schema && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/schema
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/schema
  fi
}

global_variable() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: global_variable [-h|--help] [--clean] [name|file]; Cleans/gets/updates current agent global variable configuration ($(admin_url)/global-variable)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/global-variable && return 0
  local queryParam=
  if [ "$1" = "--clean" ]
  then
    [ -n "$2" ] && queryParam="?name=$2"
    do_curl -XDELETE $(admin_url)/global-variable${queryParam}
  else
    [ -n "$1" ] && queryParam="?name=$1"
    if [ -f "$1" ]
    then
      do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/global-variable
    else
      do_curl $(admin_url)/global-variable${queryParam}
    fi
  fi
}

files() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: files [-h|--help]; Gets the files processed."
    return 0
  else
    do_curl $(admin_url)/files
  fi
}

files_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: files_configuration [-h|--help]; Manages files configuration (gets current status by default)."
    echo "                            [--enable-read-cache]  ; Enables cache for read operations."
    echo "                            [--disable-read-cache] ; Disables cache for read operations."
    return 0
  elif [ "$1" = "--enable-read-cache" ]
  then
    do_curl -XPUT "$(admin_url)/files/configuration?readCache=true"
  elif [ "$1" = "--disable-read-cache" ]
  then
    do_curl -XPUT "$(admin_url)/files/configuration?readCache=false"
  else
    do_curl $(admin_url)/files/configuration
  fi
}

udp_sockets() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: udp_sockets [-h|--help]; Gets the udp sockets processed."
    return 0
  else
    do_curl $(admin_url)/udp-sockets
  fi
}

configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: configuration [-h|--help]; Gets agent general static configuration."
    return 0
  else
    do_curl $(admin_url)/configuration
  fi
}

# -----------------------------------------------------------------------------
# TRAFFIC SERVER

server_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_configuration [-h|--help]; Manages agent server configuration (gets current status by default)."
    echo "                            [--traffic-server-ignore-request-body]             ; Ignores request body on server receptions."
    echo "                            [--traffic-server-receive-request-body]            ; Processes request body on server receptions."
    echo "                            [--traffic-server-dynamic-request-body-allocation] ; Does dynamic request body memory allocation on server receptions."
    echo "                            [--traffic-server-initial-request-body-allocation] ; Pre reserves request body memory on server receptions."
    return 0
  elif [ "$1" = "--traffic-server-ignore-request-body" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?receiveRequestBody=false"
  elif [ "$1" = "--traffic-server-receive-request-body" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?receiveRequestBody=true"
  elif [ "$1" = "--traffic-server-dynamic-request-body-allocation" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?preReserveRequestBody=false"
  elif [ "$1" = "--traffic-server-initial-request-body-allocation" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?preReserveRequestBody=true"
  else
    do_curl $(admin_url)/server/configuration
  fi
}

server_data_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_data_configuration [-h|--help]; Manages agent server data configuration (gets current status by default)."
    echo "                                 [--discard-all]     ; Discards all the events processed."
    echo "                                 [--discard-history] ; Keeps only the last event processed for a key."
    echo "                                 [--keep-all]        ; Keeps all the events processed."
    echo "                                 [--disable-purge]   ; Skips events post-removal when a provision on 'purge' state is reached."
    echo "                                 [--enable-purge]    ; Processes events post-removal when a provision on 'purge' state is reached."
    return 0
  elif [ "$1" = "--discard-all" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=true&discardKeyHistory=true"
  elif [ "$1" = "--discard-history" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=false&discardKeyHistory=true"
  elif [ "$1" = "--keep-all" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=false&discardKeyHistory=false"
  elif [ "$1" = "--disable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?disablePurge=true"
  elif [ "$1" = "--enable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?disablePurge=false"
  else
    do_curl $(admin_url)/server-data/configuration
  fi
}

server_matching() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_matching [-h|--help] [file]; Gets/updates current server matching configuration ($(admin_url)/server-matching)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/server-matching && return 0
  do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/server-matching
}

server_provision() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision [-h|--help] [--clean] [file]; Cleans/gets/updates current server provision configuration ($(admin_url)/server-provision)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/server-provision && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/server-provision
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/server-provision
  fi
}

server_provision_unused() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision_unused [-h|--help]; Get current server provision configuration still not used ($(admin_url)/server-provision/unused)." && return 0
  do_curl $(admin_url)/server-provision/unused && return 0
}

server_data() {
  local clean=
  local surf=
  local dump=

  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_data [-h|--help]; Inspects server data events ($(admin_url)/server-data)."
    echo "                   [method] [uri] [[-]event number] [event path] ; Positional filters to narrow the server data selection."
    echo "                                                                   Event number may be negative to access by reverse chronological order."
    echo "                   [--summary] [max keys]          ; Gets current server data summary to guide further queries."
    echo "                                                     Displayed keys (method/uri) could be limited (10 by default, -1: no limit)."
    echo "                   [--clean] [query filters]       ; Removes server data events."
    echo "                   [--surf] [query filters]        ; Interactive sorted (regardless method/uri) server data navigation."
    echo "                   [--dump] [query filters]        ; Dumps all sequences detected for server data under 'server-data-sequences' directory."
    return 0
  elif [ "$1" = "--summary" ]
  then
    local maxKeys=${2:-10}
    local queryParams=
    [ -n "${maxKeys}" ] && queryParams="?maxKeys=${maxKeys}"
    [ "${maxKeys}" = "-1" ] && queryParams=
    do_curl "$(admin_url)/server-data/summary${queryParams}"
    return 0
  elif [ "$1" = "--clean" ]
  then
    clean=yes
    shift
  elif [ "$1" = "--surf" ]
  then
    surf=yes
    shift
  elif [ "$1" = "--dump" ]
  then
    dump=yes
    shift
  fi

  local requestMethod=$1
  local requestUri=$2
  local eventNumber=$3
  local eventPath=$4

  local keyIndicators=""
  [ -n "${requestMethod}" ] && keyIndicators+="x"
  [ -n "${requestUri}" ] && keyIndicators+="x"
  [ "${keyIndicators}" = "x" ] && echo "Error: both method & uri must be provided" && return 1
  [ -n "${eventNumber}" -a -z "${keyIndicators}" ] && echo "Error: method/uri are also required when eventNumber is provided" && return 1
  [ -n "${eventPath}" -a -z "${eventNumber}" ] && echo "Error: eventNumber is required when eventPath is provided" && return 1

  local queryParams=
  [ -n "${requestMethod}" ] && queryParams="?requestMethod=${requestMethod}" # request URI not added here (it must be encoded with --data-urlencode)
  [ -n "${eventNumber}" ] && queryParams="${queryParams}&eventNumber=${eventNumber}"

  local curl_method=
  [ -n "${clean}" ] && curl_method="-XDELETE"

  local devnull=
  [ -n "${dump}" -o -n "${surf}" ] && devnull=">/dev/null"

  if [ -n "${requestUri}" ]
  then
    local urlencode=
    [ -n "${requestUri}" ] && urlencode="--data-urlencode requestUri=${requestUri}"
    [ -n "${eventPath}" ] && urlencode+=" --data-urlencode eventPath=${eventPath}"
    eval do_curl ${curl_method} -G ${urlencode} "$(admin_url)/server-data'${queryParams}'" ${devnull}
  else
    if [ -z "${clean}${dump}${surf}" ]
    then
      echo
      echo "Take care about storage size when querying without filters."
      echo "You may want to check the summary before: server_data --summary"
      echo
      echo "Press ENTER to continue, CTRL-C to abort ..."
      read -r dummy
    fi
    eval do_curl ${curl_method} "$(admin_url)/server-data" ${devnull}
  fi

  [ -z "${clean}${dump}${surf}" ] && return 0

  local sequences=
  if [ -n "${requestUri}" ]; then sequences=( $(pretty ".events[].serverSequence" | sort -n) ) ; else sequences=( $(pretty ".[].events[].serverSequence" | sort -n) ) ; fi
  local indx_max=${#sequences[@]}

  if [ -n "${dump}" ]
  then
    mkdir -p server-data-sequences
    local arrayPrefix=
    [ -z "${requestUri}" ] && arrayPrefix=".[] | "
    for s in ${sequences[@]}; do pretty | jq "${arrayPrefix}select (.events[].serverSequence == $s) | del (.events[] | select (.serverSequence != $s))" > server-data-sequences/$(printf "%02d\n" "$s").json ; done

  elif [ -n "${surf}" ]
  then
    if [ -n "${requestUri}" ]
    then
      pretty | jq '.method as $method | .uri as $uri | .provisionUri as $provisionUri | .events | map({events: [.], method: $method, uri: $uri, provisionUri: $provisionUri})' > /tmp/curl.out.sorted
    else
      pretty | jq 'map(. as $parent | .events |= sort_by(.serverSequence) | .events[] | {events: [.], method: $parent.method, uri: $parent.uri, provisionUri: $parent.provisionUri}) | sort_by(.events[].serverSequence)' > /tmp/curl.out.sorted
    fi

    local indx=0
    [ ! -s /tmp/curl.out.sorted ] && echo && cat /tmp/curl.out && return 0
    echo
    echo "Show also corresponding (p)rovisions or just show server [d]ata:"
    read -r opt
    [ -z "${opt}" ] && opt=d
    [ "${opt}" = "p" ] && server_provision >/dev/null
    while true
    do
      echo -e "\nMessage $((indx+1)):\n"
      jq ".[$indx]" /tmp/curl.out.sorted

      # Corresponding provision:
      if [ "${opt}" = "p" ]
      then
        local requestUri=$(jq -r ".[$indx].provisionUri" /tmp/curl.out.sorted | sed 's/\\/\\\\/g')
        if [ "${requestUri}" != "null" ]
        then
          echo -e "\nCorresponding provision processed:\n"
          local inState=$(jq -r ".[$indx].events[0].previousState" /tmp/curl.out.sorted)
          local requestMethod=$(jq -r ".[$indx].method" /tmp/curl.out.sorted)
          if [ "${inState}" == "initial" ]
          then
            local cond="(.inState == \"initial\" or .inState == null) and .requestMethod == \""${requestMethod}"\" and .requestUri == \""${requestUri}"\""
            pretty | jq ".[] | select (${cond})" | sed 's/^/      /'
          else
            local cond=".inState == \""${inState}"\" and .requestMethod == \""${requestMethod}"\" and .requestUri == \""${requestUri}"\""
            pretty | jq ".[] | select (${cond})" | sed 's/^/      /'
          fi
        fi
      fi

      indx=$((indx+1))
      [ $indx -eq $indx_max ] && echo -e "\n\nThat's all ! ($indx_max events)\n" && return 0
      echo -e "\n\nPress ENTER to print next sequence ..."
      read -r dummy
    done
  fi
}

# -----------------------------------------------------------------------------
# TRAFFIC CLIENT

client_data_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_data_configuration [-h|--help]; Manages agent client data configuration (gets current status by default)."
    echo "                                 [--discard-all]     ; Discards all the events processed."
    echo "                                 [--discard-history] ; Keeps only the last event processed for a key."
    echo "                                 [--keep-all]        ; Keeps all the events processed."
    echo "                                 [--disable-purge]   ; Skips events post-removal when a provision on 'purge' state is reached."
    echo "                                 [--enable-purge]    ; Processes events post-removal when a provision on 'purge' state is reached."
    return 0
  elif [ "$1" = "--discard-all" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=true&discardKeyHistory=true"
  elif [ "$1" = "--discard-history" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=false&discardKeyHistory=true"
  elif [ "$1" = "--keep-all" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=false&discardKeyHistory=false"
  elif [ "$1" = "--disable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?disablePurge=true"
  elif [ "$1" = "--enable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?disablePurge=false"
  else
    do_curl $(admin_url)/client-data/configuration
  fi
}

client_endpoint() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_endpoint [-h|--help] [--clean] [file]; Cleans/gets/updates current client endpoint configuration ($(admin_url)/client-endpoint)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/client-endpoint && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/client-endpoint
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/client-endpoint
  fi
}

client_provision() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_provision [-h|--help] [--clean]; Cleans/gets/updates/triggers current client provision configuration ($(admin_url)/client-provision)."
    echo "                                       [file]; Configure client provision by mean json specification."
    echo "                        [id] [id query param]; Triggers client provision identifier and optionally provide dynamics configuration (omit with empty value):"
    echo "                                               [inState, sequenceBegin, sequenceEnd, rps, repeat (true|false)]"
    return 0
  fi

  [ -z "$1" ] && do_curl $(admin_url)/client-provision && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/client-provision
  else
    if [ -f "$1" ]
    then
      do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/client-provision
    else
      local queryParams=
      [ -n "$2" ] && queryParams+="&inState=$2"
      [ -n "$3" ] && queryParams+="&sequenceBegin=$3"
      [ -n "$4" ] && queryParams+="&sequenceEnd=$4"
      [ -n "$5" ] && queryParams+="&rps=$5"
      [ -n "$6" ] && queryParams+="&repeat=$6"
      [ -n "${queryParams}" ] && queryParams=$(echo ${queryParams} | sed 's/&/?/')
      do_curl -XGET "$(admin_url)/client-provision/${1}'${queryParams}'"
    fi
  fi
}

client_provision_unused() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_provision_unused [-h|--help]; Get current client provision configuration still not used ($(admin_url)/client-provision/unused)." && return 0
  do_curl $(admin_url)/client-provision/unused && return 0
}

launch_client_provision() {
  [ "$1" = "-h" -o "$1" = "--help" -o -z "$1" ] && echo "Usage: launch_client_provision [-h|--help] <id>; Activates client provision given its identifier ($(admin_url)/client-provision/<id>)." && return 0
  do_curl -XPUT $(admin_url)/client-provision/$1
}

client_data() {
  local clean=
  local surf=
  local dump=

  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_data [-h|--help]; Inspects client data events ($(admin_url)/client-data)."
    echo "                   [client endpoint id] [method] [uri] [[-]event number] [event path] ; Positional filters to narrow the client data selection."
    echo "                                                                                        Event number may be negative to access by reverse chronological order."
    echo "                   [--summary] [max keys]          ; Gets current client data summary to guide further queries."
    echo "                                                     Displayed keys (client endpoint id/method/uri) could be limited (10 by default, -1: no limit)."
    echo "                   [--clean] [query filters]       ; Removes client data events."
    echo "                   [--surf] [query filters]        ; Interactive sorted (regardless endpoint/method/uri) client data navigation."
    echo "                   [--dump] [query filters]        ; Dumps all sequences detected for client data under 'client-data-sequences' directory."
    return 0

  elif [ "$1" = "--summary" ]
  then
    local maxKeys=${2:-10}
    local queryParams=
    [ -n "${maxKeys}" ] && queryParams="?maxKeys=${maxKeys}"
    [ "${maxKeys}" = "-1" ] && queryParams=
    do_curl "$(admin_url)/client-data/summary${queryParams}"
    return 0
  elif [ "$1" = "--clean" ]
  then
    clean=yes
    shift
  elif [ "$1" = "--surf" ]
  then
    surf=yes
    shift
  elif [ "$1" = "--dump" ]
  then
    dump=yes
    shift
  fi

  local clientEndpointId=$1
  local requestMethod=$2
  local requestUri=$3
  local eventNumber=$4
  local eventPath=$5

  local keyIndicators=""
  [ -n "${clientEndpointId}" ] && keyIndicators+="x"
  [ -n "${requestMethod}" ] && keyIndicators+="x"
  [ -n "${requestUri}" ] && keyIndicators+="x"
  [ "${keyIndicators}" != "" -a "${keyIndicators}" != "xxx" ] && echo "Error: client endpoint id & method & uri must be provided" && return 1
  [ -n "${eventNumber}" -a -z "${keyIndicators}" ] && echo "Error: client endpoint id/method/uri are also required when eventNumber is provided" && return 1
  [ -n "${eventPath}" -a -z "${eventNumber}" ] && echo "Error: eventNumber is required when eventPath is provided" && return 1

  local queryParams=
  [ -n "${clientEndpointId}" ] && queryParams="?clientEndpointId=${clientEndpointId}"
  [ -n "${requestMethod}" ] && queryParams="${queryParams}&requestMethod=${requestMethod}" # request URI not added here (it must be encoded with --data-urlencode)
  [ -n "${eventNumber}" ] && queryParams="${queryParams}&eventNumber=${eventNumber}"

  local curl_method=
  [ -n "${clean}" ] && curl_method="-XDELETE"

  local devnull=
  [ -n "${dump}" -o -n "${surf}" ] && devnull=">/dev/null"

  if [ -n "${requestUri}" ]
  then
    local urlencode=
    [ -n "${requestUri}" ] && urlencode="--data-urlencode requestUri=${requestUri}"
    [ -n "${eventPath}" ] && urlencode+=" --data-urlencode eventPath=${eventPath}"
    eval do_curl ${curl_method} -G ${urlencode} "$(admin_url)/client-data'${queryParams}'" ${devnull}
  else
    if [ -z "${clean}${dump}${surf}" ]
    then
      echo
      echo "Take care about storage size when querying without filters."
      echo "You may want to check the summary before: client_data --summary"
      echo
      echo "Press ENTER to continue, CTRL-C to abort ..."
      read -r dummy
    fi
    eval do_curl ${curl_method} "$(admin_url)/client-data" ${devnull}
  fi

  [ -z "${clean}${dump}${surf}" ] && return 0

  local sequences=
  if [ -n "${requestUri}" ]; then sequences=( $(pretty ".events[].clientSequence" | sort -n) ) ; else sequences=( $(pretty ".[].events[].clientSequence" | sort -n) ) ; fi
  local indx_max=${#sequences[@]}

  if [ -n "${dump}" ]
  then
    mkdir -p client-data-sequences
    local arrayPrefix=
    [ -z "${requestUri}" ] && arrayPrefix=".[] | "
    for s in ${sequences[@]}; do pretty | jq "${arrayPrefix}select (.events[].clientSequence == $s) | del (.events[] | select (.clientSequence != $s))" > client-data-sequences/$(printf "%02d\n" "$s").json ; done

  elif [ -n "${surf}" ]
  then
    if [ -n "${requestUri}" ]
    then
      pretty | jq '.method as $method | .uri as $uri | .events | map({events: [.], method: $method, uri: $uri})' > /tmp/curl.out.sorted
    else
      pretty | jq 'map(. as $parent | .events |= sort_by(.clientSequence) | .events[] | {events: [.], method: $parent.method, uri: $parent.uri}) | sort_by(.events[].clientSequence)' > /tmp/curl.out.sorted
    fi

    local indx=0
    [ ! -s /tmp/curl.out.sorted ] && echo && cat /tmp/curl.out && return 0
    while true
    do
      echo -e "\nMessage $((indx+1)):\n"
      jq ".[$indx]" /tmp/curl.out.sorted
      indx=$((indx+1))
      [ $indx -eq $indx_max ] && echo -e "\n\nThat's all ! ($indx_max events)\n" && return 0
      echo -e "\n\nPress ENTER to print next sequence ..."
      read -r dummy
    done
  fi
}

# -----------------------------------------------------------------------------
# OPERATION SCHEMAS

schema_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: schema_schema [-h|--help]; Gets the schema configuration schema ($(admin_url)/schema/schema)." && return 0
  do_curl "$(admin_url)/schema/schema"
}

global_variable_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: global_variable_schema [-h|--help]; Gets the agent global variable configuration schema ($(admin_url)/global-variable/schema)." && return 0
  do_curl "$(admin_url)/global-variable/schema"
}

server_matching_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_matching_schema [-h|--help]; Gets the server matching configuration schema ($(admin_url)/server-matching/schema)." && return 0
  do_curl "$(admin_url)/server-matching/schema"
}

server_provision_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision_schema [-h|--help]; Gets the server provision configuration schema ($(admin_url)/server-provision/schema)." && return 0
  do_curl "$(admin_url)/server-provision/schema"
}

client_endpoint_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_endpoint_schema [-h|--help]; Gets the client endpoint configuration schema ($(admin_url)/client-endpoint/schema)." && return 0
  do_curl "$(admin_url)/client-endpoint/schema"
}

client_provision_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_provision_schema [-h|--help]; Gets the client provision configuration schema ($(admin_url)/client-provision/schema)." && return 0
  do_curl "$(admin_url)/client-provision/schema"
}

# -----------------------------------------------------------------------------
# AUXILIARY

pretty() {
  local jq_expr=${1:-.}
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: pretty [-h|--help]; Beautifies json content for last operation response."
    echo "              [jq expression, '.' by default]; jq filter over previous content."
    echo "              Example filter: schema && pretty '.[] | select(.id==\"myRequestsSchema\")'"
    return 0
  fi
  tail -n -1 /tmp/curl.out | jq "${jq_expr}"
}

raw() {
  local jq_expr=${1:-.}
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: raw [-h|--help]; Outputs raw json content for last operation response."
    echo "           [jq expression, '.' by default]; jq filter over previous content."
    echo "           Example filter: schema && raw '.[] | select(.id==\"myRequestsSchema\")'"
    return 0
  fi
  tail -n -1 /tmp/curl.out | jq -c "${jq_expr}"
}

trace() {
  local level=$1
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: trace [-h|--help] [level: Debug|Informational|Notice|Warning|Error|Critical|Alert|Emergency]; Gets/sets h2agent tracing level."
    return 0
  fi
  if [ -n "$1" ]
  then
    echo -n "Level selected: ${level}"
    local recommended_level="Warning"
    [ "$1" != "${recommended_level}" ] && echo -n " (recommended '${recommended_level}' for normal operation)."
    echo
    PLAIN=true do_curl -XPUT $(admin_url)/logging?level=${level}
  else
    PLAIN=true do_curl -XGET $(admin_url)/logging
  fi
}

metrics() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: metrics [-h|--help]; Prometheus metrics." && return 0
  curl -s $(metrics_url)
}

snapshot() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: snapshot [-h|--help]; Creates a snapshot directory with process data & configuration."
    echo "                [target dir]; Directory where information is stored ('/tmp/snapshots/last' by default)."
    return 0
  fi

  local dir=${1:-"/tmp/snapshots/$(date +'%y%m%d.%H%M%S')"}
  mkdir -p ${dir} || return 1

  if [ -n "$1" ]
  then
    [ -n "$(ls -A ${dir})" ] && echo "Target directory '${dir}' is not empty !" && return 1
  else
    local last=/tmp/snapshots/last
    rm -f ${last} && ln -s $(basename ${dir}) ${last}
  fi

  schema && pretty > ${dir}/schema.json
  schema_schema && pretty > ${dir}/schema_schema.json
  global_variable && pretty > ${dir}/global-variable.json
  global_variable_schema && pretty > ${dir}/global-variable_schema.json
  files && pretty > ${dir}/files.json
  files_configuration && pretty > ${dir}/files-configuration.json
  udp_sockets && pretty > ${dir}/udp-sockets.json
  configuration && pretty > ${dir}/configuration.json
  server_configuration && pretty > ${dir}/server-configuration.json
  server_data_configuration && pretty > ${dir}/server-data-configuration.json
  client_data_configuration && pretty > ${dir}/client-data-configuration.json

  server_matching && pretty > ${dir}/server-matching.json
  server_matching_schema && pretty > ${dir}/server-matching_schema.json

  server_provision && pretty > ${dir}/server-provision.json
  server_provision_unused && pretty > ${dir}/server-provision_unused.json
  server_provision_schema && pretty > ${dir}/server-provision_schema.json

  server_data --summary -1 && pretty > ${dir}/server-data-summary.json
  echo | server_data && pretty > ${dir}/server-data.json
  pushd ${dir} ; server_data --dump ; popd

  client_data --summary -1 && pretty > ${dir}/client-data-summary.json
  echo | client_data && pretty > ${dir}/client-data.json
  pushd ${dir} ; client_data --dump ; popd

  client_endpoint && pretty > ${dir}/client_endpoint.json
  client_endpoint_schema && pretty > ${dir}/client_endpoint_schema.json
  client_provision && pretty > ${dir}/client-provision.json
  client_provision_unused && pretty > ${dir}/client-provision_unused.json
  client_provision_schema && pretty > ${dir}/client-provision_schema.json

  metrics > ${dir}/metrics.txt

  echo
  echo "Created snapshot at:"
  if [ -n "$1" ]
  then
    readlink -f ${dir}
  else
    ls -l ${last}
  fi
}

server_example() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_example [-h|--help]; Basic server configuration examples. Try: source <(server_example)" && return 0

  # If h2agent is up, we will suggest as example the same server matching configuration detected, to avoid breaking its behaviour
  #  (provisions and schemas are probably not harmful because of their dummy names):
  local foo_server_matching=$(curl -s --http2-prior-knowledge $(admin_url)/server-matching | jq '.' -c)
  [ -z "${foo_server_matching}" ] && foo_server_matching="{\"algorithm\":\"FullMatching\"}" # fallback to basic example

  local traffic_server_api_path=
  [ -n "${TRAFFIC_SERVER_API}" ] && traffic_server_api_path="/${TRAFFIC_SERVER_API}"

  cat << EOF

  # Configure 'dummySchemaId' to be referenced later:
  cat << ! > /tmp/dummySchema.json
  {
    "\\\$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "additionalProperties": true,
    "properties": {
      "foo": { "type": "number" }
    },
    "required": [ "foo" ]
  }
!
  jq --arg id "dummySchemaId" '. | { id: \$id, schema: . }' /tmp/dummySchema.json > /tmp/h2agent_dummySchema.json
  schema /tmp/h2agent_dummySchema.json # configuration

  ###############
  # SERVER MOCK #
  ###############

  # Configure classification algorithm:
  echo '${foo_server_matching}' > /tmp/dummyServerMatching.json
  server_matching /tmp/dummyServerMatching.json # configuration

  # Configure basic server provision to answer the same request received:
  cat << ! > /tmp/dummyServerProvision.json
  {
    "requestMethod": "POST",
    "requestUri": "${traffic_server_api_path}/my/dummy/path",
    "requestSchemaId": "dummySchemaId",
    "responseSchemaId": "dummySchemaId",
    "responseDelayMs": 0,
    "responseCode": 201,
    "responseHeaders": {
      "content-type": "application/json"
    },
    "transform": [
      { "source": "request.body", "target": "response.body.json.object" }
    ]
  }
!
  server_provision --clean
  server_provision /tmp/dummyServerProvision.json # configuration

  # Check configuration
  schema && server_matching && server_provision

  # Test it !
  server_data --clean
  \${CURL} -d'{"foo":1, "bar":2}' -H'Content-Type: application/json' $(traffic_url)${traffic_server_api_path}/my/dummy/path ; echo # must respond 201
  \${CURL} -d'{"foo":"hi", "bar":2}' -H'Content-Type: application/json' $(traffic_url)${traffic_server_api_path}/my/dummy/path ; echo # must respond 400 (foo value is not numeric)

EOF
}

client_example() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_example [-h|--help]; Basic client configuration examples. Try: source <(client_example)" && return 0

  cat << EOF

  # CLIENT EXAMPLE IMPLEMENTATION PENDING
  echo TODO !

EOF
}

help() {
  echo
  echo "===== ${PNAME} operation helpers ====="
  echo "Management interface: https://github.com/testillano/h2agent#management-interface"
  echo "Usage: help; This help summary."
  echo
  echo "=== Internal Functions And Variables ==="
  echo -n "traffic_url: $(traffic_url) (TRAFFIC_PORT=${TRAFFIC_PORT}"
  [ -n "${TRAFFIC_SERVER_API}" ] && echo -n "; TRAFFIC_SERVER_API=${TRAFFIC_SERVER_API}"
  echo ")"
  echo "admin_url:   $(admin_url) (ADMIN_PORT=${ADMIN_PORT})"
  echo "metrics_url: $(metrics_url) (METRICS_PORT=${METRICS_PORT})"
  echo "do_curl:     CURL=\"${CURL}\"; SCHEME=${SCHEME}; SERVER_ADDR=${SERVER_ADDR}"
  export -f traffic_url admin_url metrics_url do_curl
  echo
  echo "=== General Resources' Functions ==="
  for f in schema global_variable files files_configuration udp_sockets configuration; do ${f} -h | head -n +1; export -f ${f} ; done
  echo
  echo "=== Traffic Server Functions === "
  for f in server_configuration server_data_configuration server_matching server_provision server_provision_unused server_data; do ${f} -h | head -n +1; export -f ${f} ; done
  echo
  echo "=== Traffic Client Functions === "
  for f in client_data_configuration client_endpoint client_provision client_provision_unused client_data launch_client_provision; do ${f} -h | head -n +1; export -f ${f} ; done
  echo
  echo "=== Operation Schemas' Functions === "
  for f in schema_schema global_variable_schema server_matching_schema server_provision_schema client_endpoint_schema client_provision_schema; do ${f} -h | head -n +1; export -f ${f} ; done
  echo
  echo "=== Auxiliary Functions === "
  for f in pretty raw trace metrics snapshot server_example client_example; do ${f} -h | head -n +1; export -f ${f} ; done
  echo
}

#############
# EXECUTION #
#############

# Check dependencies:
if ! type curl &>/dev/null; then echo "Missing required dependency (curl) !" ; return 1 ; fi
if ! type jq &>/dev/null; then echo "Missing required dependency (jq) !" ; return 1 ; fi

# Initialize temporary and show help
touch /tmp/curl.out
help

