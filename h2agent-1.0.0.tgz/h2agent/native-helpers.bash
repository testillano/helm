#!/bin/echo "source me!"

#############
# VARIABLES #
#############
PNAME=${PNAME:-h2agent}

TRAFFIC_PORT=${TRAFFIC_PORT:-8000} # maybe proxy on 8001 ...
[ "${TRAFFIC_SERVER_API}" = "/" ] && TRAFFIC_SERVER_API=
ADMIN_PORT=${ADMIN_PORT:-8074} # maybe proxy on 8075 ...
ADMIN_SERVER_API="admin/v1"
METRICS_PORT=${METRICS_PORT:-8080}

SCHEME=${SCHEME:-http}
CURL=${CURL:-"curl -s -i --http2-prior-knowledge"} # may be just --http2, --http1.0, --http1.1, or nothing
SERVER_ADDR=${SERVER_ADDR:-localhost}

BEAUTIFY_JSON=yes

#############
# FUNCTIONS #
#############

# -----------------------------------------------------------------------------
# INTERNAL

traffic_url() {
  echo "${SCHEME}://${SERVER_ADDR}:${TRAFFIC_PORT}"
}

admin_url() {
  echo -n "${SCHEME}://${SERVER_ADDR}:${ADMIN_PORT}/${ADMIN_SERVER_API}"
}

metrics_url() {
  echo "${SCHEME}://${SERVER_ADDR}:${METRICS_PORT}/metrics"
}

do_curl() {
  echo
  echo [${CURL} "$@"]
  echo
  ${CURL} "$@" | tee /tmp/curl.out
  [ $? -ne 0 ] && return 1

  [ -n "${PLAIN}" ] && echo && return 0 # special for trace()

  # Last empty line or no line feed (no body answered):
  [ -z $(tail -c 1 /tmp/curl.out) ] && return 0

  [ -n "${BEAUTIFY_JSON}" ] && echo -e "\n\nPRETTY BODY PRINTOUT (disable on curl operation unsetting 'BEAUTIFY_JSON'):" && pretty
  echo -e "\n\n(type 'pretty' or 'raw' to isolate body printout)\n"
}

# -----------------------------------------------------------------------------
# GENERAL RESOURCES

schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: schema [-h|--help] [--clean] [file]; Cleans/gets/updates current schema configuration ($(admin_url)/schema)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/schema && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/schema
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/schema
  fi
}

global_variable() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: global_variable [-h|--help] [--clean] [name|file]; Cleans/gets/updates current agent global variable configuration ($(admin_url)/global-variable)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/global-variable && return 0
  local queryParam=
  if [ "$1" = "--clean" ]
  then
    [ -n "$2" ] && queryParam="?name=$2"
    do_curl -XDELETE $(admin_url)/global-variable${queryParam}
  else
    [ -n "$1" ] && queryParam="?name=$1"
    if [ -f "$1" -o -p "$1" -o -r "$1" ]
    then
      do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/global-variable
    else
      do_curl $(admin_url)/global-variable${queryParam}
    fi
  fi
}

files() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: files [-h|--help]; Gets the files processed."
    return 0
  else
    do_curl $(admin_url)/files
  fi
}

files_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: files_configuration [-h|--help]; Manages files configuration (gets current status by default)."
    echo "                            [--enable-read-cache]  ; Enables cache for read operations."
    echo "                            [--disable-read-cache] ; Disables cache for read operations."
    return 0
  elif [ "$1" = "--enable-read-cache" ]
  then
    do_curl -XPUT "$(admin_url)/files/configuration?readCache=true"
  elif [ "$1" = "--disable-read-cache" ]
  then
    do_curl -XPUT "$(admin_url)/files/configuration?readCache=false"
  else
    do_curl $(admin_url)/files/configuration
  fi
}

udp_sockets() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: udp_sockets [-h|--help]; Gets the udp sockets processed."
    return 0
  else
    do_curl $(admin_url)/udp-sockets
  fi
}

configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: configuration [-h|--help]; Gets agent general static configuration."
    return 0
  else
    do_curl $(admin_url)/configuration
  fi
}

# -----------------------------------------------------------------------------
# TRAFFIC SERVER

server_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_configuration [-h|--help]; Manages agent server configuration (gets current status by default)."
    echo "                            [--traffic-server-ignore-request-body]             ; Ignores request body on server receptions."
    echo "                            [--traffic-server-receive-request-body]            ; Processes request body on server receptions."
    echo "                            [--traffic-server-dynamic-request-body-allocation] ; Does dynamic request body memory allocation on server receptions."
    echo "                            [--traffic-server-initial-request-body-allocation] ; Pre reserves request body memory on server receptions."
    return 0
  elif [ "$1" = "--traffic-server-ignore-request-body" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?receiveRequestBody=false"
  elif [ "$1" = "--traffic-server-receive-request-body" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?receiveRequestBody=true"
  elif [ "$1" = "--traffic-server-dynamic-request-body-allocation" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?preReserveRequestBody=false"
  elif [ "$1" = "--traffic-server-initial-request-body-allocation" ]
  then
    do_curl -XPUT "$(admin_url)/server/configuration?preReserveRequestBody=true"
  else
    do_curl $(admin_url)/server/configuration
  fi
}

server_data_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_data_configuration [-h|--help]; Manages agent server data configuration (gets current status by default)."
    echo "                                 [--discard-all]     ; Discards all the events processed."
    echo "                                 [--discard-history] ; Keeps only the last event processed for a key."
    echo "                                 [--keep-all]        ; Keeps all the events processed."
    echo "                                 [--disable-purge]   ; Skips events post-removal when a provision on 'purge' state is reached."
    echo "                                 [--enable-purge]    ; Processes events post-removal when a provision on 'purge' state is reached."
    return 0
  elif [ "$1" = "--discard-all" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=true&discardKeyHistory=true"
  elif [ "$1" = "--discard-history" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=false&discardKeyHistory=true"
  elif [ "$1" = "--keep-all" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?discard=false&discardKeyHistory=false"
  elif [ "$1" = "--disable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?disablePurge=true"
  elif [ "$1" = "--enable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/server-data/configuration?disablePurge=false"
  else
    do_curl $(admin_url)/server-data/configuration
  fi
}

server_matching() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_matching [-h|--help] [file]; Gets/updates current server matching configuration ($(admin_url)/server-matching)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/server-matching && return 0
  do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/server-matching
}

server_provision() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision [-h|--help] [--clean] [file]; Cleans/gets/updates current server provision configuration ($(admin_url)/server-provision)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/server-provision && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/server-provision
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/server-provision
  fi
}

server_provision_unused() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision_unused [-h|--help]; Get current server provision configuration still not used ($(admin_url)/server-provision/unused)." && return 0
  do_curl $(admin_url)/server-provision/unused && return 0
}

server_data() {
  local clean=
  local surf=
  local dump=

  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: server_data [-h|--help]; Inspects server data events ($(admin_url)/server-data)."
    echo "                   [method] [uri] [[-]event number] [event path] ; Positional filters to narrow the server data selection."
    echo "                                                                   Event number may be negative to access by reverse chronological order."
    echo "                   [--summary] [max keys]          ; Gets current server data summary to guide further queries."
    echo "                                                     Displayed keys (method/uri) could be limited (10 by default, -1: no limit)."
    echo "                   [--clean] [query filters]       ; Removes server data events."
    echo "                   [--surf] [query filters]        ; Interactive sorted (regardless method/uri) server data navigation."
    echo "                   [--dump] [query filters]        ; Dumps all sequences detected for server data under 'server-data-sequences' directory."
    return 0
  elif [ "$1" = "--summary" ]
  then
    local maxKeys=${2:-10}
    local queryParams=
    [ -n "${maxKeys}" ] && queryParams="?maxKeys=${maxKeys}"
    [ "${maxKeys}" = "-1" ] && queryParams=
    do_curl "$(admin_url)/server-data/summary${queryParams}"
    return 0
  elif [ "$1" = "--clean" ]
  then
    clean=yes
    shift
  elif [ "$1" = "--surf" ]
  then
    surf=yes
    shift
  elif [ "$1" = "--dump" ]
  then
    dump=yes
    shift
  fi

  local requestMethod=$1
  local requestUri=$2
  local eventNumber=$3
  local eventPath=$4

  local keyIndicators=""
  [ -n "${requestMethod}" ] && keyIndicators+="x"
  [ -n "${requestUri}" ] && keyIndicators+="x"
  [ "${keyIndicators}" = "x" ] && echo "Error: both method & uri must be provided" && return 1
  [ -n "${eventNumber}" -a -z "${keyIndicators}" ] && echo "Error: method/uri are also required when eventNumber is provided" && return 1
  [ -n "${eventPath}" -a -z "${eventNumber}" ] && echo "Error: eventNumber is required when eventPath is provided" && return 1

  local queryParams=
  [ -n "${requestMethod}" ] && queryParams="?requestMethod=${requestMethod}" # request URI not added here (it must be encoded with --data-urlencode)
  [ -n "${eventNumber}" ] && queryParams="${queryParams}&eventNumber=${eventNumber}"

  local curl_method=
  [ -n "${clean}" ] && curl_method="-XDELETE"

  local devnull=
  [ -n "${dump}" -o -n "${surf}" ] && devnull=">/dev/null"

  if [ -n "${requestUri}" ]
  then
    local urlencode=
    [ -n "${requestUri}" ] && urlencode="--data-urlencode requestUri=\"${requestUri}\""
    [ -n "${eventPath}" ] && urlencode+=" --data-urlencode eventPath=${eventPath}"
    eval do_curl ${curl_method} -G ${urlencode} "$(admin_url)/server-data${queryParams}" ${devnull}
  else
    if [ -z "${clean}${dump}${surf}" ]
    then
      echo
      echo "Take care about storage size when querying without filters."
      echo "You may want to check the summary before: server_data --summary"
      echo
      echo "Press ENTER to continue, CTRL-C to abort ..."
      read -r dummy
    fi
    eval do_curl ${curl_method} "$(admin_url)/server-data" ${devnull}
  fi

  [ -z "${clean}${dump}${surf}" ] && return 0

  local sequences=
  if [ -n "${requestUri}" ]; then sequences=( $(pretty ".events[].serverSequence" | sort -n) ) ; else sequences=( $(pretty ".[].events[].serverSequence" | sort -n) ) ; fi
  local indx_max=${#sequences[@]}

  if [ -n "${dump}" ]
  then
    mkdir -p server-data-sequences
    local arrayPrefix=
    [ -z "${requestUri}" ] && arrayPrefix=".[] | "
    for s in ${sequences[@]}; do pretty | jq "${arrayPrefix}select (.events[].serverSequence == $s) | del (.events[] | select (.serverSequence != $s))" > server-data-sequences/$(printf "%02d\n" "$s").json ; done

  elif [ -n "${surf}" ]
  then
    if [ -n "${requestUri}" ]
    then
      pretty | jq '.method as $method | .uri as $uri | .provisionUri as $provisionUri | .events | map({events: [.], method: $method, uri: $uri, provisionUri: $provisionUri})' > /tmp/curl.out.sorted
    else
      pretty | jq 'map(. as $parent | .events |= sort_by(.serverSequence) | .events[] | {events: [.], method: $parent.method, uri: $parent.uri, provisionUri: $parent.provisionUri}) | sort_by(.events[].serverSequence)' > /tmp/curl.out.sorted
    fi

    local indx=0
    [ ! -s /tmp/curl.out.sorted ] && echo && cat /tmp/curl.out && return 0
    echo
    echo "Show also corresponding (p)rovisions or just show server [d]ata:"
    read -r opt
    [ -z "${opt}" ] && opt=d
    [ "${opt}" = "p" ] && server_provision >/dev/null
    while true
    do
      echo -e "\nMessage $((indx+1)):\n"
      jq ".[$indx]" /tmp/curl.out.sorted

      # Corresponding provision:
      if [ "${opt}" = "p" ]
      then
        local requestUri=$(jq -r ".[$indx].provisionUri" /tmp/curl.out.sorted | sed 's/\\/\\\\/g')
        if [ "${requestUri}" != "null" ]
        then
          echo -e "\nCorresponding provision processed:\n"
          local inState=$(jq -r ".[$indx].events[0].previousState" /tmp/curl.out.sorted)
          local requestMethod=$(jq -r ".[$indx].method" /tmp/curl.out.sorted)
          if [ "${inState}" == "initial" ]
          then
            local cond="(.inState == \"initial\" or .inState == null) and .requestMethod == \""${requestMethod}"\" and .requestUri == \""${requestUri}"\""
            pretty | jq ".[] | select (${cond})" | sed 's/^/      /'
          else
            local cond=".inState == \""${inState}"\" and .requestMethod == \""${requestMethod}"\" and .requestUri == \""${requestUri}"\""
            pretty | jq ".[] | select (${cond})" | sed 's/^/      /'
          fi
        fi
      fi

      indx=$((indx+1))
      [ $indx -eq $indx_max ] && echo -e "\n\nThat's all ! ($indx_max events)\n" && return 0
      echo -e "\n\nPress ENTER to print next sequence ..."
      read -r dummy
    done
  fi
}

check_storage() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: check_storage [-h|--help]; Checks if loaded provisions need event storage but it is disabled."
    echo "                     [--server] ; Check server provisions only."
    echo "                     [--client] ; Check client provisions only."
    echo "                     By default, checks both server and client."
    echo "                     Returns 0 if consistent, 1 if storage is needed but disabled."
    return 0
  fi

  local check_server=true
  local check_client=true
  [ "$1" = "--server" ] && check_client=false
  [ "$1" = "--client" ] && check_server=false

  local rc=0

  if [ "${check_server}" = "true" ]
  then
    do_curl "$(admin_url)/server-data/configuration" >/dev/null 2>&1
    local needs=$(pretty '.needsStorage // false' 2>/dev/null)
    local stores=$(pretty '.storeEvents // false' 2>/dev/null)
    local history=$(pretty '.storeEventsKeyHistory // false' 2>/dev/null)
    if [ "${needs}" = "true" ]
    then
      if [ "${stores}" != "true" ]
      then
        echo "Warning: server provisions require storage but it is disabled. Consider: server_data_configuration --keep-all"
        rc=1
      elif [ "${history}" != "true" ]
      then
        echo "Warning: server provisions require storage but key history is disabled. Consider: server_data_configuration --keep-all"
        rc=1
      fi
    fi
  fi

  if [ "${check_client}" = "true" ]
  then
    do_curl "$(admin_url)/client-data/configuration" >/dev/null 2>&1
    local needs=$(pretty '.needsStorage // false' 2>/dev/null)
    local stores=$(pretty '.storeEvents // false' 2>/dev/null)
    local history=$(pretty '.storeEventsKeyHistory // false' 2>/dev/null)
    if [ "${needs}" = "true" ]
    then
      if [ "${stores}" != "true" ]
      then
        echo "Warning: client provisions require storage but it is disabled. Consider: client_data_configuration --keep-all"
        rc=1
      elif [ "${history}" != "true" ]
      then
        echo "Warning: client provisions require storage but key history is disabled. Consider: client_data_configuration --keep-all"
        rc=1
      fi
    fi
  fi

  [ ${rc} -eq 0 ] && echo "Storage configuration is consistent."
  return ${rc}
}

# -----------------------------------------------------------------------------
# TRAFFIC CLIENT

client_data_configuration() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_data_configuration [-h|--help]; Manages agent client data configuration (gets current status by default)."
    echo "                                 [--discard-all]     ; Discards all the events processed."
    echo "                                 [--discard-history] ; Keeps only the last event processed for a key."
    echo "                                 [--keep-all]        ; Keeps all the events processed."
    echo "                                 [--disable-purge]   ; Skips events post-removal when a provision on 'purge' state is reached."
    echo "                                 [--enable-purge]    ; Processes events post-removal when a provision on 'purge' state is reached."
    return 0
  elif [ "$1" = "--discard-all" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=true&discardKeyHistory=true"
  elif [ "$1" = "--discard-history" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=false&discardKeyHistory=true"
  elif [ "$1" = "--keep-all" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?discard=false&discardKeyHistory=false"
  elif [ "$1" = "--disable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?disablePurge=true"
  elif [ "$1" = "--enable-purge" ]
  then
    do_curl -XPUT "$(admin_url)/client-data/configuration?disablePurge=false"
  else
    do_curl $(admin_url)/client-data/configuration
  fi
}

client_endpoint() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_endpoint [-h|--help] [--clean] [file]; Cleans/gets/updates current client endpoint configuration ($(admin_url)/client-endpoint)." && return 0
  [ -z "$1" ] && do_curl $(admin_url)/client-endpoint && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/client-endpoint
  else
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/client-endpoint
  fi
}

client_provision() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_provision [-h|--help] [--clean]; Cleans/gets/configures current client provision configuration ($(admin_url)/client-provision)."
    echo "                                       [file]; Configure client provision by mean json specification."
    echo "                                   [id] [inState]; Filter provisions by id and optionally by inState."
    echo "                          [--dynamics] [period] [--wait]; Shows active dynamics with remaining sequences and ETA."
    echo "                                                 No period: single shot. Period <= 0: fastest. Period > 0: refresh interval."
    echo "                                                 --wait: blocking mode, keeps polling when no activity (waits for new triggers)."
    echo
    echo "  Examples:"
    echo "    client_provision                                      # List all provisions"
    echo "    client_provision --clean                              # Delete all provisions"
    echo "    client_provision my-provision.json                    # Configure from file"
    echo "    client_provision myFlow                               # Show provisions with id 'myFlow'"
    echo "    client_provision myFlow established                   # Show provision with id 'myFlow' and inState 'established'"
    echo "    client_provision --dynamics                           # Single shot dynamics"
    echo "    client_provision --dynamics 0                         # Fastest continuous"
    echo "    client_provision --dynamics 2                         # Refresh every 2s"
    echo "    client_provision --dynamics --wait                    # Fastest continuous, blocking"
    echo "    client_provision --dynamics 2 --wait                  # Refresh 2s, blocking"
    return 0
  fi

  [ -z "$1" ] && do_curl $(admin_url)/client-provision && return 0
  if [ "$1" = "--clean" ]
  then
    do_curl -XDELETE $(admin_url)/client-provision
  elif [ "$1" = "--dynamics" ]
  then
    shift
    local period= wait=false
    while [ $# -gt 0 ]; do
      case "$1" in
        --wait) wait=true ;;
        *) period=$1 ;;
      esac
      shift
    done
    local single_shot=false
    local waiting_dot=false
    [ -z "$period" ] && single_shot=true && period=0
    while true; do
      local json=$(curl -s --http2-prior-knowledge $(admin_url)/client-provision 2>/dev/null)
      local output=
      [ -n "$json" -a "$json" != "[]" ] && output=$(echo "$json" | jq -r '
        .[] | select(.dynamics and .dynamics.rps > 0 and .dynamics.sequenceEnd >= .dynamics.sequence) |
        .id as $id |
        .dynamics |
        (.sequenceEnd - .sequence) as $remaining |
        (($remaining / .rps) | floor) as $eta |
        "\($id): seq=\(.sequence)/\(.sequenceEnd) remaining=\($remaining) rps=\(.rps) repeat=\(.repeat) ETA=\($eta)s"
      ')
      if [ -n "$output" ]; then
        ${waiting_dot} && echo && waiting_dot=false
        echo "$output"
        ${single_shot} && break
        [ "$period" -gt 0 ] 2>/dev/null && sleep "$period"
      elif ! ${wait}; then
        echo "No active dynamics."
        break
      else
        ${waiting_dot} || echo -n "No active dynamics."
        echo -n "."
        waiting_dot=true
        sleep 1
      fi
    done
  elif [ -f "$1" -o -p "$1" -o -r "$1" ]
  then
    do_curl -XPOST -d@${1} -H 'content-type:application/json' $(admin_url)/client-provision
  else
    local id=$1
    local inState=$2
    local filter=".[] | select(.id == \"${id}\")"
    [ -n "${inState}" ] && filter+=" | select(.inState == \"${inState}\")"
    do_curl $(admin_url)/client-provision >/dev/null && pretty | jq "[${filter}]"
  fi
}

client_provision_trigger() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_provision_trigger [-h|--help] <id> [sequenceBegin] [sequenceEnd] [rps] [repeat] [--in-state <state>]"
    echo "                               Triggers a client provision. Omitted params keep server-side defaults."
    echo
    echo "  Examples:"
    echo "    client_provision_trigger myFlow                               # Sync trigger (sequence=0, inState=initial)"
    echo "    client_provision_trigger myFlow --in-state established        # Sync trigger with custom inState"
    echo "    client_provision_trigger myFlow 0 99999 5000                  # Async trigger at 5000 rps"
    echo "    client_provision_trigger myFlow 0 99999 5000 true             # Async trigger with repeat"
    echo "    client_provision_trigger myFlow 0 99999 5000 --in-state step2 # Async trigger with custom inState"
    return 0
  fi

  [ -z "$1" ] && echo "Error: provision id required" && return 1

  local id=$1; shift
  local seqBegin= seqEnd= rps= repeat= inState=
  while [ $# -gt 0 ]; do
    case "$1" in
      --in-state) inState=$2; shift ;;
      *) [ -z "${seqBegin}" ] && seqBegin=$1 && shift && continue
         [ -z "${seqEnd}" ] && seqEnd=$1 && shift && continue
         [ -z "${rps}" ] && rps=$1 && shift && continue
         [ -z "${repeat}" ] && repeat=$1 && shift && continue
         ;;
    esac
    shift
  done
  local queryParams=
  [ -n "${seqBegin}" ] && queryParams+="&sequenceBegin=${seqBegin}"
  [ -n "${seqEnd}" ] && queryParams+="&sequenceEnd=${seqEnd}"
  [ -n "${rps}" ] && queryParams+="&rps=${rps}"
  [ -n "${repeat}" ] && queryParams+="&repeat=${repeat}"
  [ -n "${inState}" ] && queryParams+="&inState=${inState}"
  [ -n "${queryParams}" ] && queryParams=$(echo ${queryParams} | sed 's/&/?/')
  do_curl -XGET "$(admin_url)/client-provision/${id}${queryParams}"
}

client_provision_rps() {
  if [ "$1" = "-h" -o "$1" = "--help" -o $# -lt 2 ]
  then
    echo "Usage: client_provision_rps <id> <rps> [--repeat true|false] [--in-state <state>]; Changes RPS/repeat for a running provision."
    return 0
  fi
  local id=$1 rps=$2; shift 2
  local inState="initial" repeat=
  while [ $# -gt 0 ]; do
    case "$1" in
      --in-state) inState=$2; shift ;;
      --repeat) repeat=$2; shift ;;
    esac
    shift
  done
  local q="rps=${rps}&inState=${inState}"
  [ -n "$repeat" ] && q+="&repeat=${repeat}"
  do_curl -XGET "$(admin_url)/client-provision/${id}?${q}"
}

client_provision_unused() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_provision_unused [-h|--help]; Get current client provision configuration still not used ($(admin_url)/client-provision/unused)." && return 0
  do_curl $(admin_url)/client-provision/unused && return 0
}

client_data() {
  local clean=
  local surf=
  local dump=

  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: client_data [-h|--help]; Inspects client data events ($(admin_url)/client-data)."
    echo "                   [client endpoint id] [method] [uri] [[-]event number] [event path] ; Positional filters to narrow the client data selection."
    echo "                                                                                        Event number may be negative to access by reverse chronological order."
    echo "                   [--summary] [max keys]          ; Gets current client data summary to guide further queries."
    echo "                                                     Displayed keys (client endpoint id/method/uri) could be limited (10 by default, -1: no limit)."
    echo "                   [--clean] [query filters]       ; Removes client data events."
    echo "                   [--surf] [query filters]        ; Interactive sorted (regardless endpoint/method/uri) client data navigation."
    echo "                   [--dump] [query filters]        ; Dumps all sequences detected for client data under 'client-data-sequences' directory."
    return 0

  elif [ "$1" = "--summary" ]
  then
    local maxKeys=${2:-10}
    local queryParams=
    [ -n "${maxKeys}" ] && queryParams="?maxKeys=${maxKeys}"
    [ "${maxKeys}" = "-1" ] && queryParams=
    do_curl "$(admin_url)/client-data/summary${queryParams}"
    return 0
  elif [ "$1" = "--clean" ]
  then
    clean=yes
    shift
  elif [ "$1" = "--surf" ]
  then
    surf=yes
    shift
  elif [ "$1" = "--dump" ]
  then
    dump=yes
    shift
  fi

  local clientEndpointId=$1
  local requestMethod=$2
  local requestUri=$3
  local eventNumber=$4
  local eventPath=$5

  local keyIndicators=""
  [ -n "${clientEndpointId}" ] && keyIndicators+="x"
  [ -n "${requestMethod}" ] && keyIndicators+="x"
  [ -n "${requestUri}" ] && keyIndicators+="x"
  [ "${keyIndicators}" != "" -a "${keyIndicators}" != "xxx" ] && echo "Error: client endpoint id & method & uri must be provided" && return 1
  [ -n "${eventNumber}" -a -z "${keyIndicators}" ] && echo "Error: client endpoint id/method/uri are also required when eventNumber is provided" && return 1
  [ -n "${eventPath}" -a -z "${eventNumber}" ] && echo "Error: eventNumber is required when eventPath is provided" && return 1

  local queryParams=
  [ -n "${clientEndpointId}" ] && queryParams="?clientEndpointId=${clientEndpointId}"
  [ -n "${requestMethod}" ] && queryParams="${queryParams}&requestMethod=${requestMethod}" # request URI not added here (it must be encoded with --data-urlencode)
  [ -n "${eventNumber}" ] && queryParams="${queryParams}&eventNumber=${eventNumber}"

  local curl_method=
  [ -n "${clean}" ] && curl_method="-XDELETE"

  local devnull=
  [ -n "${dump}" -o -n "${surf}" ] && devnull=">/dev/null"

  if [ -n "${requestUri}" ]
  then
    local urlencode=
    [ -n "${requestUri}" ] && urlencode="--data-urlencode requestUri=\"${requestUri}\""
    [ -n "${eventPath}" ] && urlencode+=" --data-urlencode eventPath=${eventPath}"
    eval do_curl ${curl_method} -G ${urlencode} "$(admin_url)/client-data${queryParams}" ${devnull}
  else
    if [ -z "${clean}${dump}${surf}" ]
    then
      echo
      echo "Take care about storage size when querying without filters."
      echo "You may want to check the summary before: client_data --summary"
      echo
      echo "Press ENTER to continue, CTRL-C to abort ..."
      read -r dummy
    fi
    eval do_curl ${curl_method} "$(admin_url)/client-data" ${devnull}
  fi

  [ -z "${clean}${dump}${surf}" ] && return 0

  local sequences=
  if [ -n "${requestUri}" ]; then sequences=( $(pretty ".events[].clientSequence" | sort -n) ) ; else sequences=( $(pretty ".[].events[].clientSequence" | sort -n) ) ; fi
  local indx_max=${#sequences[@]}

  if [ -n "${dump}" ]
  then
    mkdir -p client-data-sequences
    local arrayPrefix=
    [ -z "${requestUri}" ] && arrayPrefix=".[] | "
    for s in ${sequences[@]}; do pretty | jq "${arrayPrefix}select (.events[].clientSequence == $s) | del (.events[] | select (.clientSequence != $s))" > client-data-sequences/$(printf "%02d\n" "$s").json ; done

  elif [ -n "${surf}" ]
  then
    if [ -n "${requestUri}" ]
    then
      pretty | jq '.method as $method | .uri as $uri | .events | map({events: [.], method: $method, uri: $uri})' > /tmp/curl.out.sorted
    else
      pretty | jq 'map(. as $parent | .events |= sort_by(.clientSequence) | .events[] | {events: [.], method: $parent.method, uri: $parent.uri}) | sort_by(.events[].clientSequence)' > /tmp/curl.out.sorted
    fi

    local indx=0
    [ ! -s /tmp/curl.out.sorted ] && echo && cat /tmp/curl.out && return 0
    while true
    do
      echo -e "\nMessage $((indx+1)):\n"
      jq ".[$indx]" /tmp/curl.out.sorted
      indx=$((indx+1))
      [ $indx -eq $indx_max ] && echo -e "\n\nThat's all ! ($indx_max events)\n" && return 0
      echo -e "\n\nPress ENTER to print next sequence ..."
      read -r dummy
    done
  fi
}

# -----------------------------------------------------------------------------
# OPERATION SCHEMAS

schema_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: schema_schema [-h|--help]; Gets the schema configuration schema ($(admin_url)/schema/schema)." && return 0
  do_curl "$(admin_url)/schema/schema"
}

global_variable_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: global_variable_schema [-h|--help]; Gets the agent global variable configuration schema ($(admin_url)/global-variable/schema)." && return 0
  do_curl "$(admin_url)/global-variable/schema"
}

server_matching_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_matching_schema [-h|--help]; Gets the server matching configuration schema ($(admin_url)/server-matching/schema)." && return 0
  do_curl "$(admin_url)/server-matching/schema"
}

server_provision_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_provision_schema [-h|--help]; Gets the server provision configuration schema ($(admin_url)/server-provision/schema)." && return 0
  do_curl "$(admin_url)/server-provision/schema"
}

client_endpoint_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_endpoint_schema [-h|--help]; Gets the client endpoint configuration schema ($(admin_url)/client-endpoint/schema)." && return 0
  do_curl "$(admin_url)/client-endpoint/schema"
}

client_provision_schema() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_provision_schema [-h|--help]; Gets the client provision configuration schema ($(admin_url)/client-provision/schema)." && return 0
  do_curl "$(admin_url)/client-provision/schema"
}

# -----------------------------------------------------------------------------
# AUXILIARY

pretty() {
  local jq_expr=${1:-.}
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: pretty [-h|--help]; Beautifies json content for last operation response."
    echo "              [jq expression, '.' by default]; jq filter over previous content."
    echo "              Example filter: schema && pretty '.[] | select(.id==\"myRequestsSchema\")'"
    return 0
  fi
  tail -n -1 /tmp/curl.out | jq "${jq_expr}"
}

raw() {
  local jq_expr=${1:-.}
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: raw [-h|--help]; Outputs raw json content for last operation response."
    echo "           [jq expression, '.' by default]; jq filter over previous content."
    echo "           Example filter: schema && raw '.[] | select(.id==\"myRequestsSchema\")'"
    return 0
  fi
  tail -n -1 /tmp/curl.out | jq -c "${jq_expr}"
}

trace() {
  local level=$1
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: trace [-h|--help] [level: Debug|Informational|Notice|Warning|Error|Critical|Alert|Emergency]; Gets/sets h2agent tracing level."
    return 0
  fi
  if [ -n "$1" ]
  then
    echo -n "Level selected: ${level}"
    local recommended_level="Warning"
    [ "$1" != "${recommended_level}" ] && echo -n " (recommended '${recommended_level}' for normal operation)."
    echo
    PLAIN=true do_curl -XPUT $(admin_url)/logging?level=${level}
  else
    PLAIN=true do_curl -XGET $(admin_url)/logging
  fi
}

metrics() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: metrics [-h|--help]; Prometheus metrics." && return 0
  curl -s $(metrics_url)
}

traffic_summary() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: traffic_summary [-h|--help] [--show] [--clean] [<t1> <t2>]"
    echo "       Traffic counter summary from prometheus metrics."
    echo
    echo "       (no args)   Save a counters snapshot and print its timestamp."
    echo "       --show      List saved snapshots (does not save a new one)."
    echo "       <t1> <t2>   Compute delta between two snapshots by timestamp."
    echo "                   Auto-detects server/client from metric presence."
    echo "                   Shows PASS/FAIL verdict for client automatically."
    echo "       --clean     Remove all saved snapshots."
    echo
    echo "       Snapshots: /tmp/.h2agent_traffic_summaries/counters.<unix_ts>"
    echo "       Only counter metrics are stored (no gauges or histograms)."
    echo
    echo "       Workflow: traffic_summary              # save baseline"
    echo "                 # ... run your test ..."
    echo "                 traffic_summary              # save post-test"
    echo "                 traffic_summary --show       # list snapshots"
    echo "                 traffic_summary <t1> <t2>    # delta + verdict"
    return 0
  fi

  local snap_dir="/tmp/.h2agent_traffic_summaries"

  if [ "$1" = "--clean" ]
  then
    rm -rf "${snap_dir}"
    echo "Snapshots removed."
    return 0
  fi

  mkdir -p "${snap_dir}"

  # Show history
  if [ "$1" = "--show" ]
  then
    local files=$(ls -1 "${snap_dir}"/counters.* 2>/dev/null | sort)
    if [ -z "$files" ]; then
      echo "No snapshots saved yet."
      return 0
    fi
    echo "[timestamp unix] [date/time]"
    for f in ${files}; do
      local t=${f##*.}
      printf "%-14s   %s\n" "${t}" "$(date -d @${t} '+%Y-%m-%d %H:%M:%S')"
    done
    return 0
  fi

  # No args: save snapshot
  if [ $# -eq 0 ]
  then
    local m=$(curl -s $(metrics_url))
    [ -z "$m" ] && echo "No metrics available (is h2agent running?)" && return 1
    local ts=$(date +%s)
    echo "$m" | grep '_counter{' > "${snap_dir}/counters.${ts}"
    echo "Snapshot saved: ${ts}  $(date -d @${ts} '+%Y-%m-%d %H:%M:%S')"
    return 0
  fi

  # Two args: delta between timestamps
  if [ $# -ne 2 ]
  then
    traffic_summary -h
    return 1
  fi

  local f1="${snap_dir}/counters.$1" f2="${snap_dir}/counters.$2"
  [ ! -f "$f1" ] && echo "Snapshot $1 not found." && return 1
  [ ! -f "$f2" ] && echo "Snapshot $2 not found." && return 1

  # Counter delta helper: f2 minus f1
  _tc() {
    local pattern=$1
    local v2=$(awk "/${pattern}/{s+=\$2}END{print s+0}" "$f2")
    local v1=$(awk "/${pattern}/{s+=\$2}END{print s+0}" "$f1")
    echo $((v2 - v1))
  }

  echo "=== Traffic Summary ==="
  echo "From: $1  $(date -d @$1 '+%Y-%m-%d %H:%M:%S')"
  echo "To:   $2  $(date -d @$2 '+%Y-%m-%d %H:%M:%S')"
  echo

  # Server (auto-detect)
  if grep -q '^h2agent_traffic_server_' "$f2"
  then
    local srv_accepted=$(_tc '^h2agent_traffic_server_observed_requests_accepted_counter\{')
    local srv_errored=$(_tc '^h2agent_traffic_server_observed_requests_errored_counter\{')
    local srv_responses=$(_tc '^h2agent_traffic_server_observed_responses_counter\{')
    local srv_prov_ok=$(_tc '^h2agent_traffic_server_provisioned_requests_counter\{.*result="successful"')
    local srv_prov_fail=$(_tc '^h2agent_traffic_server_provisioned_requests_counter\{.*result="failed"')
    local srv_purge_ok=$(_tc '^h2agent_traffic_server_purged_contexts_counter\{.*result="successful"')
    local srv_purge_fail=$(_tc '^h2agent_traffic_server_purged_contexts_counter\{.*result="failed"')

    echo "--- Server ---"
    echo "Requests:    ${srv_accepted} accepted, ${srv_errored} errored"
    echo "Responses:   ${srv_responses}"

    local codes=$(grep '^h2agent_traffic_server_observed_responses_counter{' "$f2" | sed 's/.*status_code="\([^"]*\)".*/\1/' | sort -u)
    for code in ${codes}; do
      local count=$(_tc "^h2agent_traffic_server_observed_responses_counter\{.*status_code=\"${code}\"")
      [ $count -gt 0 ] && echo "  ${code}: ${count}"
    done

    echo "Provisioned: ${srv_prov_ok} ok / ${srv_prov_fail} failed"
    echo "Purged:      ${srv_purge_ok} ok / ${srv_purge_fail} failed"
    echo
  fi

  # Client (auto-detect) + verdict
  if grep -q '^h2agent_traffic_client_' "$f2"
  then
    local sent=$(_tc '^h2agent_traffic_client_observed_requests_sents_counter\{')
    local unsent=$(_tc '^h2agent_traffic_client_observed_requests_unsent_counter\{')
    local timedout=$(_tc '^h2agent_traffic_client_observed_responses_timedout_counter\{')
    local jc_fail=$(_tc '^h2agent_traffic_client_response_validation_failures_counter\{')
    local rx_2xx=$(_tc '^h2agent_traffic_client_observed_responses_received_counter\{.*status_code="2')
    local rx_3xx=$(_tc '^h2agent_traffic_client_observed_responses_received_counter\{.*status_code="3')
    local rx_4xx=$(_tc '^h2agent_traffic_client_observed_responses_received_counter\{.*status_code="4')
    local rx_5xx=$(_tc '^h2agent_traffic_client_observed_responses_received_counter\{.*status_code="5')

    local received=$((rx_2xx + rx_3xx + rx_4xx + rx_5xx))
    local failed=$((unsent + timedout + rx_4xx + rx_5xx))
    local total=$((sent + unsent))

    echo "--- Client ---"
    echo "Sent:       ${sent}"
    echo "Unsent:     ${unsent}"
    echo "Received:   ${received} (2xx:${rx_2xx} 3xx:${rx_3xx} 4xx:${rx_4xx} 5xx:${rx_5xx})"
    echo "Timeouts:   ${timedout}"
    [ $jc_fail -gt 0 ] && echo "JC failures: ${jc_fail}"
    echo "---"
    if [ $failed -eq 0 ] && [ $total -gt 0 ]; then
      echo "PASS: 100% (${total}/${total})"
    elif [ $total -gt 0 ]; then
      local pass_pct=$(awk "BEGIN{printf \"%.2f\", ($total - $failed) * 100 / $total}")
      echo "FAIL: ${pass_pct}% pass ($((total - failed))/${total}, ${failed} failed)"
    else
      echo "NO DATA"
    fi
  fi

  unset -f _tc
}

snapshot() {
  if [ "$1" = "-h" -o "$1" = "--help" ]
  then
    echo "Usage: snapshot [-h|--help]; Creates a snapshot directory with process data & configuration."
    echo "                [target dir]; Directory where information is stored ('/tmp/snapshots/last' by default)."
    return 0
  fi

  local dir=${1:-"/tmp/snapshots/$(date +'%y%m%d.%H%M%S')"}
  mkdir -p ${dir} || return 1

  if [ -n "$1" ]
  then
    [ -n "$(ls -A ${dir})" ] && echo "Target directory '${dir}' is not empty !" && return 1
  else
    local last=/tmp/snapshots/last
    rm -f ${last} && ln -s $(basename ${dir}) ${last}
  fi

  mkdir -p ${dir}/{general,schemas,server,client}

  # General
  configuration && pretty > ${dir}/general/configuration.json
  schema && pretty > ${dir}/general/schema.json
  global_variable && pretty > ${dir}/general/global-variable.json
  files && pretty > ${dir}/general/files.json
  files_configuration && pretty > ${dir}/general/files-configuration.json
  udp_sockets && pretty > ${dir}/general/udp-sockets.json
  metrics > ${dir}/general/metrics.txt

  # Schemas
  schema_schema && pretty > ${dir}/schemas/schema.json
  global_variable_schema && pretty > ${dir}/schemas/global-variable.json
  server_matching_schema && pretty > ${dir}/schemas/server-matching.json
  server_provision_schema && pretty > ${dir}/schemas/server-provision.json
  client_endpoint_schema && pretty > ${dir}/schemas/client-endpoint.json
  client_provision_schema && pretty > ${dir}/schemas/client-provision.json

  # Server
  server_configuration && pretty > ${dir}/server/configuration.json
  server_data_configuration && pretty > ${dir}/server/data-configuration.json
  server_matching && pretty > ${dir}/server/matching.json
  server_provision && pretty > ${dir}/server/provision.json
  server_provision_unused && pretty > ${dir}/server/provision-unused.json
  server_data --summary -1 && pretty > ${dir}/server/data-summary.json
  echo | server_data && pretty > ${dir}/server/data.json
  pushd ${dir}/server ; server_data --dump ; [ -d server-data-sequences ] && mv server-data-sequences data-sequences ; popd

  # Client
  client_data_configuration && pretty > ${dir}/client/data-configuration.json
  client_endpoint && pretty > ${dir}/client/endpoint.json
  client_provision && pretty > ${dir}/client/provision.json
  client_provision_unused && pretty > ${dir}/client/provision-unused.json
  client_data --summary -1 && pretty > ${dir}/client/data-summary.json
  echo | client_data && pretty > ${dir}/client/data.json
  pushd ${dir}/client ; client_data --dump ; [ -d client-data-sequences ] && mv client-data-sequences data-sequences ; popd

  echo
  echo "Created snapshot at:"
  if [ -n "$1" ]
  then
    readlink -f ${dir}
  else
    ls -l ${last}
  fi
}

server_example() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: server_example [-h|--help]; Basic server configuration examples. Try: source <(server_example)" && return 0

  # If h2agent is up, we will suggest as example the same server matching configuration detected, to avoid breaking its behaviour
  #  (provisions and schemas are probably not harmful because of their dummy names):
  local foo_server_matching=$(curl -s --http2-prior-knowledge $(admin_url)/server-matching | jq '.' -c)
  [ -z "${foo_server_matching}" ] && foo_server_matching="{\"algorithm\":\"FullMatching\"}" # fallback to basic example

  local traffic_server_api_path=
  [ -n "${TRAFFIC_SERVER_API}" ] && traffic_server_api_path="/${TRAFFIC_SERVER_API}"

  cat << EOF

  # Configure 'dummySchemaId' to be referenced later:
  cat << ! > /tmp/dummySchema.json
  {
    "\\\$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "additionalProperties": true,
    "properties": {
      "foo": { "type": "number" }
    },
    "required": [ "foo" ]
  }
!
  jq --arg id "dummySchemaId" '. | { id: \$id, schema: . }' /tmp/dummySchema.json > /tmp/h2agent_dummySchema.json
  schema /tmp/h2agent_dummySchema.json # configuration

  ###############
  # SERVER MOCK #
  ###############

  # Configure classification algorithm:
  echo '${foo_server_matching}' > /tmp/dummyServerMatching.json
  server_matching /tmp/dummyServerMatching.json # configuration

  # Configure basic server provision to answer the same request received:
  cat << ! > /tmp/dummyServerProvision.json
  {
    "requestMethod": "POST",
    "requestUri": "${traffic_server_api_path}/my/dummy/path",
    "requestSchemaId": "dummySchemaId",
    "responseSchemaId": "dummySchemaId",
    "responseDelayMs": 0,
    "responseCode": 201,
    "responseHeaders": {
      "content-type": "application/json"
    },
    "transform": [
      { "source": "request.body", "target": "response.body.json.object" }
    ]
  }
!
  server_provision --clean
  server_provision /tmp/dummyServerProvision.json # configuration

  # Check configuration
  schema && server_matching && server_provision

  # Test it !
  server_data --clean
  \${CURL} -d'{"foo":1, "bar":2}' -H'Content-Type: application/json' $(traffic_url)${traffic_server_api_path}/my/dummy/path ; echo # must respond 201
  \${CURL} -d'{"foo":"hi", "bar":2}' -H'Content-Type: application/json' $(traffic_url)${traffic_server_api_path}/my/dummy/path ; echo # must respond 400 (foo value is not numeric)

EOF
}

client_example() {
  [ "$1" = "-h" -o "$1" = "--help" ] && echo "Usage: client_example [-h|--help]; Basic client configuration examples. Try: source <(client_example)" && return 0

  cat << EOF

  # CLIENT EXAMPLE IMPLEMENTATION PENDING
  echo TODO !

EOF
}

help() {
  echo
  echo "===== ${PNAME} operation helpers ====="
  echo "Management interface: https://github.com/testillano/h2agent#management-interface"
  echo "Usage: help; This help summary."
  echo
  echo "=== Internal Functions And Variables ==="
  echo -n "traffic_url: $(traffic_url) (TRAFFIC_PORT=${TRAFFIC_PORT}"
  [ -n "${TRAFFIC_SERVER_API}" ] && echo -n "; TRAFFIC_SERVER_API=${TRAFFIC_SERVER_API}"
  echo ")"
  echo "admin_url:   $(admin_url) (ADMIN_PORT=${ADMIN_PORT})"
  echo "metrics_url: $(metrics_url) (METRICS_PORT=${METRICS_PORT})"
  echo "do_curl:     CURL=\"${CURL}\"; SCHEME=${SCHEME}; SERVER_ADDR=${SERVER_ADDR}"
  export -f traffic_url admin_url metrics_url do_curl
  echo
  echo "=== General Resources' Functions ==="
  for f in schema global_variable files files_configuration udp_sockets configuration; do ${f} -h | head -n 1; export -f ${f} ; done
  echo
  echo "=== Traffic Server Functions === "
  for f in server_configuration server_data_configuration server_matching server_provision server_provision_unused server_data; do ${f} -h | head -n 1; export -f ${f} ; done
  echo
  echo "=== Traffic Client Functions === "
  for f in client_data_configuration client_endpoint client_provision client_provision_trigger client_provision_rps client_provision_unused client_data traffic_summary; do ${f} -h | head -n 1; export -f ${f} ; done
  echo
  echo "=== Operation Schemas' Functions === "
  for f in schema_schema global_variable_schema server_matching_schema server_provision_schema client_endpoint_schema client_provision_schema; do ${f} -h | head -n 1; export -f ${f} ; done
  echo
  echo "=== Auxiliary Functions === "
  for f in pretty raw trace metrics snapshot check_storage server_example client_example; do ${f} -h | head -n 1; export -f ${f} ; done
  echo
}

#############
# EXECUTION #
#############

# Check dependencies:
if ! type curl &>/dev/null; then echo "Missing required dependency (curl) !" ; return 1 ; fi
if ! type jq &>/dev/null; then echo "Missing required dependency (jq) !" ; return 1 ; fi

# Initialize temporary and show help
touch /tmp/curl.out
help

